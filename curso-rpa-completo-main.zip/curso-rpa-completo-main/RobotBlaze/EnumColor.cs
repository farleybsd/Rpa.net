﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotBlaze
{
    public enum EnumColor
    {
        PRETO = 2,
        VERMELHO = 1,
        BRANCO = 0
    }
}
