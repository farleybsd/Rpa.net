﻿using EasyAutomationFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotBitcoinWPF.Driver
{
    public class MercadoDriver : Web
    {
        public void BuyBitcoin()
        {
            StartBrowser();
            Navigate("https://www.mercadobitcoin.com.br/conta/login/");
            AssignValue(TypeElement.Id, "id_cpfcnpj", "06455514541");
            AssignValue(TypeElement.Id, "id_password", "123456789")
                .element.SendKeys(OpenQA.Selenium.Keys.Enter);
        }
    }
}
