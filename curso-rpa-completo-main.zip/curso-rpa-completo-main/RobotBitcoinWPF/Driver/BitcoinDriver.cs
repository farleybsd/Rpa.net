﻿using EasyAutomationFramework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.PhantomJS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotBitcoinWPF.Driver
{
    public class BitcoinDriver : Web
    {
        public BitcoinDriver()
        {
            this.StartBrowser();
        }

        public EasyReturn.Web StartBrowser(TypeDriver typeDriver = TypeDriver.GoogleChorme, string pathCache = null)
        {
            try
            {
          
                ChromeDriverService chromeDriverService = ChromeDriverService.CreateDefaultService();
                chromeDriverService.HideCommandPromptWindow = true;
                ChromeOptions chromeOptions = new ChromeOptions();
                if (string.IsNullOrEmpty(pathCache))
                {
                    chromeOptions.AddArgument("--incognito");
                }
                else
                {
                    chromeOptions.AddArgument("user-data-dir=" + pathCache);
                }
                chromeOptions.AddArgument("--headless");
                chromeOptions.AddExcludedArgument("enable-automation");
                chromeOptions.AddAdditionalCapability("useAutomationExtension", false);
                chromeOptions.AddArgument("--start-maximized");
                driver = new ChromeDriver(chromeDriverService, chromeOptions);
                        
                  

                return new EasyReturn.Web
                {
                    driver = driver,
                    Sucesso = true
                };
            }
            catch (Exception ex)
            {
                return new EasyReturn.Web
                {
                    driver = driver,
                    Sucesso = false,
                    Error = ex.Message.ToString()
                };
            }
        }

        public double GetValueBitcoin()
        {
            Navigate("https://www.google.com/search?q=valor+do+bitcoin&rlz=1C1ONGR_pt-PTBR1059BR1059&oq=valor+do+bitcoin&aqs=chrome..69i57.2276j0j9&sourceid=chrome&ie=UTF-8");

            var bitcoin = GetValue(TypeElement.Xpath, "//*[@id=\"crypto-updatable_2\"]/div[3]/div[2]/span[1]");

            if (bitcoin.Sucesso)
            {
                var valid = double.TryParse(bitcoin.Value, out double resultBitcoin);
                if(valid) return resultBitcoin;
            }

            return 0;
        }

        public bool ChecksValueBitcoint(double valueCurrent, double desiredValue)
        {
            if(valueCurrent <= desiredValue) return true;

            return false;
        }
    }
}
