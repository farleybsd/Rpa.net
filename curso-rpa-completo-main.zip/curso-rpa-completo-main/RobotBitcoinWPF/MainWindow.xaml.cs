﻿using RobotBitcoinWPF.Driver;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RobotBitcoinWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool _startedRobot = false;
        private BitcoinDriver _bitcoinDriver;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void startBtn_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtDesiredValue.Text))
            {
                MessageBox.Show("Please, enter the desired amount");
            }
            else
            {
                _startedRobot = true;
                stopBtn.Visibility = Visibility.Visible;
                startBtn.Visibility = Visibility.Hidden;

                new Thread(() =>
                {
                    Thread.CurrentThread.IsBackground = true;
                    StartCotacaoBitcoin();
                }).Start();
            }
        }

        private void StartCotacaoBitcoin()
        {
            double desiredValue = 0;
            Dispatcher.BeginInvoke(() => desiredValue = Convert.ToDouble(txtDesiredValue.Text));

            _bitcoinDriver = new BitcoinDriver();

            var cultureInfo = new CultureInfo("pt-BR");

            while (_startedRobot)
            {
                var value = _bitcoinDriver.GetValueBitcoin();
                Dispatcher.BeginInvoke(() => lblBitcoin.Text = value.ToString("C", cultureInfo));

                if(_bitcoinDriver.ChecksValueBitcoint(value, desiredValue))
                {
                    Dispatcher.BeginInvoke(() =>
                    {
                        if(WindowState == WindowState.Minimized)
                            WindowState = WindowState.Normal;
                        else
                        {
                            WindowState = WindowState.Normal;
                            Topmost = true;
                            BringIntoView();
                        }

                        Activate();
                    });
                }

                Thread.Sleep(TimeSpan.FromSeconds(5));
            }
        }


        private void stopBtn_Click(object sender, RoutedEventArgs e)
        {
            _startedRobot = false;
            stopBtn.Visibility = Visibility.Hidden;
            startBtn.Visibility = Visibility.Visible;

            _bitcoinDriver.CloseBrowser();
        }

        private void butBtn_Click(object sender, RoutedEventArgs e)
        {
            var mercado = new MercadoDriver();
            mercado.BuyBitcoin();
        }
    }
}
