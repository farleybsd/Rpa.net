﻿
using RobotWhatsapp;

var whatsapps = new WhatsappDriver();

whatsapps.ReadMessage();