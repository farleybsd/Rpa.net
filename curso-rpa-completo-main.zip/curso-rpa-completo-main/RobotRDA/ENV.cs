﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotRDA
{
    public static class ENV
    {
        public static string EMAIL = "wedin12369@gmail.com";
        public static string PASSWORD = "Wedin12345";
    }
}
