﻿namespace RobotDesktop
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            btn_start = new Button();
            btn_map = new Button();
            btn_add_text = new Button();
            btn_stop_map = new Button();
            lv_itens = new ListView();
            etapa = new ColumnHeader();
            tipo = new ColumnHeader();
            valor = new ColumnHeader();
            lbl_x = new Label();
            lbl_y = new Label();
            SuspendLayout();
            // 
            // btn_start
            // 
            btn_start.BackgroundImage = (Image)resources.GetObject("btn_start.BackgroundImage");
            btn_start.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btn_start.ForeColor = Color.Black;
            btn_start.Location = new Point(21, 12);
            btn_start.Name = "btn_start";
            btn_start.Size = new Size(179, 45);
            btn_start.TabIndex = 0;
            btn_start.Text = "INICIAR";
            btn_start.UseVisualStyleBackColor = true;
            btn_start.Click += btn_start_Click;
            // 
            // btn_map
            // 
            btn_map.BackgroundImage = (Image)resources.GetObject("btn_map.BackgroundImage");
            btn_map.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btn_map.ForeColor = Color.White;
            btn_map.Location = new Point(21, 63);
            btn_map.Name = "btn_map";
            btn_map.Size = new Size(179, 45);
            btn_map.TabIndex = 1;
            btn_map.Text = "MAPEAR";
            btn_map.UseVisualStyleBackColor = true;
            btn_map.Click += btn_map_Click;
            // 
            // btn_add_text
            // 
            btn_add_text.BackgroundImage = (Image)resources.GetObject("btn_add_text.BackgroundImage");
            btn_add_text.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btn_add_text.ForeColor = Color.White;
            btn_add_text.Location = new Point(21, 114);
            btn_add_text.Name = "btn_add_text";
            btn_add_text.Size = new Size(179, 45);
            btn_add_text.TabIndex = 2;
            btn_add_text.Text = "ADICIONAR TEXTO";
            btn_add_text.UseVisualStyleBackColor = true;
            btn_add_text.Click += btn_add_text_Click;
            // 
            // btn_stop_map
            // 
            btn_stop_map.BackgroundImage = (Image)resources.GetObject("btn_stop_map.BackgroundImage");
            btn_stop_map.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btn_stop_map.Location = new Point(21, 63);
            btn_stop_map.Name = "btn_stop_map";
            btn_stop_map.Size = new Size(179, 45);
            btn_stop_map.TabIndex = 3;
            btn_stop_map.Text = "PARAR MAP.";
            btn_stop_map.UseVisualStyleBackColor = true;
            btn_stop_map.Visible = false;
            btn_stop_map.Click += btn_stop_map_Click;
            // 
            // lv_itens
            // 
            lv_itens.BackgroundImage = (Image)resources.GetObject("lv_itens.BackgroundImage");
            lv_itens.Columns.AddRange(new ColumnHeader[] { etapa, tipo, valor });
            lv_itens.ForeColor = Color.White;
            lv_itens.Location = new Point(225, 12);
            lv_itens.Name = "lv_itens";
            lv_itens.Size = new Size(306, 198);
            lv_itens.TabIndex = 4;
            lv_itens.UseCompatibleStateImageBehavior = false;
            lv_itens.View = View.Details;
            // 
            // etapa
            // 
            etapa.Text = "etapa";
            // 
            // tipo
            // 
            tipo.Text = "tipo";
            tipo.Width = 100;
            // 
            // valor
            // 
            valor.Text = "valor";
            valor.Width = 140;
            // 
            // lbl_x
            // 
            lbl_x.AutoSize = true;
            lbl_x.BackColor = Color.Transparent;
            lbl_x.ForeColor = Color.White;
            lbl_x.Location = new Point(551, 24);
            lbl_x.Name = "lbl_x";
            lbl_x.Size = new Size(21, 20);
            lbl_x.TabIndex = 5;
            lbl_x.Text = "X:";
            // 
            // lbl_y
            // 
            lbl_y.AutoSize = true;
            lbl_y.BackColor = Color.Transparent;
            lbl_y.ForeColor = Color.White;
            lbl_y.Location = new Point(551, 63);
            lbl_y.Name = "lbl_y";
            lbl_y.Size = new Size(20, 20);
            lbl_y.TabIndex = 6;
            lbl_y.Text = "Y:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(616, 232);
            Controls.Add(lbl_y);
            Controls.Add(lbl_x);
            Controls.Add(lv_itens);
            Controls.Add(btn_stop_map);
            Controls.Add(btn_add_text);
            Controls.Add(btn_map);
            Controls.Add(btn_start);
            Name = "Form1";
            Text = "IDE - Desktop";
            Deactivate += Form1_Deactivate;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_start;
        private Button btn_map;
        private Button btn_add_text;
        private Button btn_stop_map;
        private ListView lv_itens;
        private ColumnHeader etapa;
        private ColumnHeader tipo;
        private ColumnHeader valor;
        private Label lbl_x;
        private Label lbl_y;
    }
}